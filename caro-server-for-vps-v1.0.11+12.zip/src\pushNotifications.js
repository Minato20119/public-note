'use strict';

const fs = require('fs');
const path = require('path');

// The service-account key is a real secret (full admin rights to send push
// under this Firebase project) — it lives beside src/ on the server itself,
// never in git, and is never sent to any client. See README for how to
// generate it from the Firebase console.
const KEY_FILE = path.join(__dirname, '..', 'firebase-service-account.json');
const MIN_GAP_MS = 5 * 1000;

// Generic, chat-unrelated decoy texts — same disguise idea as the in-app
// local notifications (see app/lib/services/notification_service.dart), but
// this path can't read the recipient's real battery level (that's only
// known on-device), so it sticks to non-committal suggestions instead of a
// fake specific number that might not match reality.
const DECOY_MESSAGES = [
  'Có một số file tạm không còn dùng đến — dọn dẹp để giải phóng dung lượng.',
  'Bộ nhớ máy gần đầy. Xoá bớt file rác giúp máy chạy mượt hơn.',
  'Hãy kiểm tra mức pin của thiết bị nếu chưa sạc gần đây.',
];

let messaging = null;
if (fs.existsSync(KEY_FILE)) {
  try {
    const { initializeApp, cert } = require('firebase-admin/app');
    const { getMessaging } = require('firebase-admin/messaging');
    const serviceAccount = JSON.parse(fs.readFileSync(KEY_FILE, 'utf8'));
    const app = initializeApp({ credential: cert(serviceAccount) });
    messaging = getMessaging(app);
    console.log('[push] Firebase service account loaded — push notifications enabled.');
  } catch (err) {
    console.warn('[push] Failed to initialize firebase-admin:', err.message);
  }
} else {
  console.warn(
    '[push] No firebase-service-account.json next to server/ — push ' +
      'notifications for a fully-closed app are disabled (local ' +
      'notifications while the app is still running are unaffected).',
  );
}

/** @type {Map<string, number>} clientId -> last push timestamp */
const lastSentAt = new Map();

/// Sends a disguised push to [clientId]'s registered device, unless one was
/// already sent within [MIN_GAP_MS] — same spam-guard idea as the in-app
/// notification debounce, just tracked server-side since this path fires
/// independently of any client code running.
async function sendPushIfDue(clientId, token) {
  if (!messaging || !token) return;
  const now = Date.now();
  const last = lastSentAt.get(clientId) || 0;
  if (now - last < MIN_GAP_MS) return;
  lastSentAt.set(clientId, now);

  const body = DECOY_MESSAGES[Math.floor(Math.random() * DECOY_MESSAGES.length)];
  try {
    await messaging.send({
      token,
      // No title, same reasoning as the local notifications: Android
      // already shows its own app-name header above this, and a second
      // bold title line would just repeat that identity.
      notification: { title: '', body },
      android: { priority: 'high' },
    });
  } catch (err) {
    console.warn('[push] failed to send to', clientId, '-', err.message);
  }
}

module.exports = { sendPushIfDue };
