'use strict';

const fs = require('fs');
const path = require('path');

// clientId -> FCM registration token, so a message can still be pushed to a
// device that has no live WebSocket connection at all (app fully closed).
// Persisted so a token survives a server restart — otherwise every restart
// would silently disable push until each device reconnects once.
const DATA_DIR = path.join(__dirname, '..', 'data');
const TOKENS_FILE = path.join(DATA_DIR, 'push_tokens.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

/** @type {Record<string, string>} */
let tokens = {};
try {
  tokens = JSON.parse(fs.readFileSync(TOKENS_FILE, 'utf8'));
} catch {
  tokens = {};
}

function persist() {
  fs.writeFile(TOKENS_FILE, JSON.stringify(tokens), () => {});
}

function setToken(clientId, token) {
  if (!clientId || typeof token !== 'string' || !token) return;
  if (tokens[clientId] !== token) {
    tokens[clientId] = token;
    persist();
  }
}

function getToken(clientId) {
  return tokens[clientId] || null;
}

module.exports = { setToken, getToken };
