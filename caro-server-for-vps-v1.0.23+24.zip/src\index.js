'use strict';

const fs = require('fs');
const path = require('path');
const http = require('http');
const express = require('express');
const multer = require('multer');
const { WebSocketServer } = require('ws');

const { handleGameConnection } = require('./gameHub');
const { handleChatConnection } = require('./chatHub');
const { checkAccessHash } = require('./chatAuth');

const PORT = process.env.PORT || 8080;
const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
const WEB_APP_DIR = path.join(__dirname, '..', '..', 'app', 'build', 'web');

const app = express();
// No CORS middleware: the only browser client is the web build this same
// server serves at `/` (same-origin, needs no CORS headers at all), and the
// Android app isn't a browser — it isn't subject to CORS regardless. Wide-
// open CORS (the previous `app.use(cors())` with no origin restriction)
// only ever mattered for some *other* website's JS trying to read responses
// from here; there's no legitimate case for that, so there's nothing to
// grant.

// Same shared-secret check as the chat WebSocket (see chatAuth.js) — without
// this, anyone who finds the server could upload arbitrary files here even
// without ever knowing the app's private-chat passphrase.
//
// Accepts the hash from either the `x-access-hash` header (used by the
// Dart `http` package for uploads, and by images on web/mobile) or a `h`
// query param — HTML5 <video> (and plain <img>) elements have no way to
// attach a custom header to the request the browser makes for their `src`,
// so video playback needs the hash embedded in the URL itself instead.
function requireChatAuth(req, res, next) {
  const hash = req.get('x-access-hash') || req.query.h;
  if (!checkAccessHash(hash)) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  next();
}

// Uploaded media (chat attachments) is only ever meant to be reachable by
// someone who has already authenticated into the hidden chat — gate the GET
// route the same way the POST /upload route already is, otherwise anyone who
// guesses/enumerates a filename can view private media with no auth at all.
app.use(
  '/uploads',
  requireChatAuth,
  (req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    next();
  },
  express.static(UPLOAD_DIR),
);
// Serves the compiled Flutter web build (production mode — no dwds debug
// channel, so it doesn't drop the page out from under an in-progress game
// the way `flutter run` dev mode occasionally does).
app.use(express.static(WEB_APP_DIR));

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`);
  },
});

const IMAGE_EXT = new Set(['.jpg', '.jpeg', '.png', '.gif', '.webp']);
const VIDEO_EXT = new Set(['.mp4', '.mov', '.webm']);
// Generic documents/archives — a separate category from image/video, kept
// only briefly (see sweepOldUploads below) since the VPS this runs on has
// limited disk space and these aren't meant as long-term storage, just
// quick sharing.
const DOC_EXT = new Set([
  '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.txt', '.csv',
  '.zip', '.rar', '.7z', '.apk',
]);
const ALLOWED_EXT = new Set([...IMAGE_EXT, ...VIDEO_EXT, ...DOC_EXT]);

const upload = multer({
  storage,
  limits: { fileSize: 70 * 1024 * 1024 }, // 70MB
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, ALLOWED_EXT.has(ext));
  },
});

app.post('/upload', requireChatAuth, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'no_file_or_unsupported_type' });
  const ext = path.extname(req.file.originalname).toLowerCase();
  const type = VIDEO_EXT.has(ext) ? 'video' : IMAGE_EXT.has(ext) ? 'image' : 'file';
  const response = { url: `/uploads/${req.file.filename}`, type };
  // Only generic files carry their original name back to the client — the
  // on-disk name always stays the random one from `storage.filename` above
  // (never trust a client-supplied name for the actual filesystem path);
  // this is purely what the chat UI displays. Images/videos never showed a
  // filename in the UI so there's nothing to preserve for them.
  if (type === 'file') {
    response.name = path.basename(req.file.originalname).slice(0, 150);
  }
  res.json(response);
});

// Uploaded media isn't tied to how long its chat message is kept (a message
// can be set to never auto-delete, or the file could outlive a deleted
// message entirely) — without this, disk usage on the /uploads/ dir only
// ever grows. Deleting the file is independent of message retention; the
// chat UI already shows a broken-image/broken-video/missing-file state
// gracefully when an attachment's file is gone. Images/videos keep the
// original 7-day window; generic documents/archives get a much shorter
// 24h window instead — this server's disk is limited, and unlike photos
// people actually want to keep around, these are more "quick share" than
// something worth holding onto.
const MEDIA_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;
const DOC_MAX_AGE_MS = 24 * 60 * 60 * 1000;

function sweepOldUploads() {
  fs.readdir(UPLOAD_DIR, (err, files) => {
    if (err) return;
    const now = Date.now();
    for (const file of files) {
      const filePath = path.join(UPLOAD_DIR, file);
      fs.stat(filePath, (statErr, stats) => {
        if (statErr || !stats.isFile()) return;
        const ext = path.extname(file).toLowerCase();
        const maxAge = ext && !DOC_EXT.has(ext) ? MEDIA_MAX_AGE_MS : DOC_MAX_AGE_MS;
        if (now - stats.mtimeMs > maxAge) fs.unlink(filePath, () => {});
      });
    }
  });
}

sweepOldUploads();
setInterval(sweepOldUploads, 60 * 60 * 1000); // hourly is plenty for a 24h window

app.get('/health', (_req, res) => res.json({ ok: true }));

const server = http.createServer(app);

// Caps how large a single incoming WS frame can be — `ws`'s own default
// (~100MB) is generous enough that one oversized frame from a misbehaving
// or malicious client could pressure server memory for no legitimate
// reason; every real message here (chat text, game moves) is tiny, so a
// generous-but-bounded 1MB leaves headroom without leaving this wide open.
const WS_MAX_PAYLOAD_BYTES = 1 * 1024 * 1024;

const gameWss = new WebSocketServer({ noServer: true, maxPayload: WS_MAX_PAYLOAD_BYTES });
gameWss.on('connection', handleGameConnection);

const chatWss = new WebSocketServer({ noServer: true, maxPayload: WS_MAX_PAYLOAD_BYTES });
chatWss.on('connection', handleChatConnection);

server.on('upgrade', (req, socket, head) => {
  const { pathname } = new URL(req.url, `http://${req.headers.host}`);
  if (pathname === '/ws/game') {
    gameWss.handleUpgrade(req, socket, head, (ws) => gameWss.emit('connection', ws, req));
  } else if (pathname === '/ws/chat') {
    chatWss.handleUpgrade(req, socket, head, (ws) => chatWss.emit('connection', ws, req));
  } else {
    socket.destroy();
  }
});

server.listen(PORT, () => {
  console.log(`Caro Master server listening on :${PORT}`);
  console.log(`  game ws: ws://<host>:${PORT}/ws/game`);
  console.log(`  chat ws: ws://<host>:${PORT}/ws/chat`);
  console.log(`  uploads: http://<host>:${PORT}/upload (POST, field "file")`);
});
