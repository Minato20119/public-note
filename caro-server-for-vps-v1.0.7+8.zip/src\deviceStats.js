'use strict';

const { EventEmitter } = require('events');

// Aggregate, anonymous install/usage counters only — no message content, no
// per-device detail is ever exposed past a count. Kept as its own module
// (rather than folded into chatHub) because it's driven by a separate
// /ws/presence connection that every install opens on app start, regardless
// of whether that install ever unlocks the private chat.
//
// Deliberately in-memory only, not persisted to disk: "total devices" is
// meant to answer "how many installs have connected to *this running
// build*", not a lifetime-forever count that just grows across every
// redeploy — so it naturally resets to 0 whenever the server process
// restarts (which is exactly when a new build starts running).
/** @type {Record<string, {firstSeen: number, lastSeen: number}>} */
const registry = {};

// clientId -> set of currently-open presence sockets. A Set (not just a
// counter) so the same device reconnecting (or opening two tabs on web)
// still only ever counts as one online device.
/** @type {Map<string, Set<any>>} */
const onlineByClient = new Map();

const emitter = new EventEmitter();

function recordDevice(clientId) {
  const now = Date.now();
  if (!registry[clientId]) {
    registry[clientId] = { firstSeen: now, lastSeen: now };
  } else {
    registry[clientId].lastSeen = now;
  }
}

function markOnline(clientId, socket) {
  recordDevice(clientId);
  let sockets = onlineByClient.get(clientId);
  if (!sockets) {
    sockets = new Set();
    onlineByClient.set(clientId, sockets);
  }
  sockets.add(socket);
  emitter.emit('change');
}

function markOffline(clientId, socket) {
  const sockets = onlineByClient.get(clientId);
  if (!sockets) return;
  sockets.delete(socket);
  if (sockets.size === 0) onlineByClient.delete(clientId);
  emitter.emit('change');
}

function getStats() {
  return {
    totalDevices: Object.keys(registry).length,
    onlineDevices: onlineByClient.size,
  };
}

function onChange(listener) {
  emitter.on('change', listener);
}

module.exports = { markOnline, markOffline, getStats, onChange };
