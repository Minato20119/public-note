'use strict';

const deviceStats = require('./deviceStats');

// Deliberately the simplest possible protocol: a device connects, says who
// it is once, and the socket staying open *is* the "online" signal — no
// heartbeat messages, no auth (this carries no private content, just an
// anonymous install id, so it doesn't need the chat access-code gate).
function handlePresenceConnection(ws) {
  let clientId = null;

  ws.on('message', (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch {
      return;
    }
    if (msg.type === 'hello' && typeof msg.clientId === 'string' && msg.clientId) {
      clientId = msg.clientId;
      deviceStats.markOnline(clientId, ws);
    }
  });

  function cleanup() {
    if (clientId) deviceStats.markOffline(clientId, ws);
  }

  ws.on('close', cleanup);
  ws.on('error', cleanup);
}

module.exports = { handlePresenceConnection };
