'use strict';

const { v4: uuid } = require('uuid');
const { createBoard, at, isInside, place, checkWinAt, isFull } = require('./gameLogic');

const PLAYER_X = 1;
const PLAYER_O = 2;
const SYMBOL = { [PLAYER_X]: 'X', [PLAYER_O]: 'O' };

/** @type {Map<string, Room>} */
const rooms = new Map();

function generateRoomCode() {
  let code;
  do {
    code = String(Math.floor(100000 + Math.random() * 900000));
  } while (rooms.has(code));
  return code;
}

function send(ws, payload) {
  if (ws.readyState === ws.OPEN) ws.send(JSON.stringify(payload));
}

// The board is a sparse, dynamically-expanding grid (see gameLogic.js /
// board_logic.dart), so nothing here technically overflows — but an
// attacker-supplied extreme boardSize is still echoed straight to the other
// player's client, which sizes its canvas as `boardSize * cellSize` and can
// hang/crash rendering it. winLength also needs a floor (1 would let the
// very first move "win" instantly) and a ceiling no bigger than the board.
const MIN_BOARD_SIZE = 5;
const MAX_BOARD_SIZE = 30;
const MIN_WIN_LENGTH = 3;
const MAX_WIN_LENGTH = 10;
const MAX_NAME_LENGTH = 40;

function clampBoardSize(value) {
  if (!Number.isInteger(value)) return 15;
  return Math.min(MAX_BOARD_SIZE, Math.max(MIN_BOARD_SIZE, value));
}

function clampWinLength(value, boardSize) {
  const fallback = Math.min(5, boardSize);
  if (!Number.isInteger(value)) return fallback;
  return Math.min(MAX_WIN_LENGTH, Math.max(MIN_WIN_LENGTH, Math.min(value, boardSize)));
}

function sanitizeName(name, fallback) {
  if (typeof name !== 'string' || !name.trim()) return fallback;
  return name.trim().slice(0, MAX_NAME_LENGTH);
}

class Room {
  constructor(code, boardSize, winLength) {
    this.code = code;
    this.boardSize = boardSize;
    this.winLength = winLength;
    this.board = createBoard(boardSize);
    this.turn = PLAYER_X;
    this.nextStarter = PLAYER_X; // who opens the next rematch (loser of the last game)
    this.status = 'waiting'; // waiting -> playing -> finished
    /** @type {{id:string, ws:any, name:string, symbol:number}[]} */
    this.players = [];
  }

  broadcast(payload, exceptId) {
    for (const p of this.players) {
      if (p.id !== exceptId) send(p.ws, payload);
    }
  }

  opponentOf(playerId) {
    return this.players.find((p) => p.id !== playerId);
  }
}

function handleGameConnection(ws) {
  const playerId = uuid();
  let currentRoom = null;

  ws.on('message', (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch {
      return send(ws, { type: 'error', message: 'invalid_json' });
    }

    switch (msg.type) {
      case 'create_room': {
        const boardSize = clampBoardSize(msg.boardSize);
        const winLength = clampWinLength(msg.winLength, boardSize);
        const code = generateRoomCode();
        const room = new Room(code, boardSize, winLength);
        room.players.push({
          id: playerId,
          ws,
          name: sanitizeName(msg.playerName, 'Player 1'),
          symbol: PLAYER_X,
        });
        rooms.set(code, room);
        currentRoom = room;
        send(ws, {
          type: 'room_created',
          roomCode: code,
          symbol: 'X',
          boardSize,
          winLength,
        });
        break;
      }

      case 'join_room': {
        const room = rooms.get(msg.roomCode);
        if (!room) return send(ws, { type: 'error', message: 'room_not_found' });
        if (room.players.length >= 2) {
          return send(ws, { type: 'error', message: 'room_full' });
        }
        const joinerName = sanitizeName(msg.playerName, 'Player 2');
        room.players.push({
          id: playerId,
          ws,
          name: joinerName,
          symbol: PLAYER_O,
        });
        room.status = 'playing';
        currentRoom = room;

        const host = room.players[0];
        send(ws, {
          type: 'room_joined',
          roomCode: room.code,
          symbol: 'O',
          boardSize: room.boardSize,
          winLength: room.winLength,
          opponentName: host.name,
        });
        send(host.ws, {
          type: 'opponent_joined',
          opponentName: joinerName,
        });
        break;
      }

      case 'move': {
        const room = currentRoom;
        if (!room || room.status !== 'playing') return;
        const player = room.players.find((p) => p.id === playerId);
        if (!player || player.symbol !== room.turn) {
          return send(ws, { type: 'error', message: 'not_your_turn' });
        }
        const { row, col } = msg;
        if (
          !Number.isInteger(row) ||
          !Number.isInteger(col) ||
          !isInside(room.board, row, col) ||
          at(room.board, row, col) !== 0
        ) {
          return send(ws, { type: 'error', message: 'invalid_move' });
        }

        place(room.board, row, col, player.symbol);
        const result = checkWinAt(room.board, room.winLength, row, col);
        const symbol = SYMBOL[player.symbol];

        if (result.won) {
          room.status = 'finished';
          room.nextStarter = player.symbol === PLAYER_X ? PLAYER_O : PLAYER_X; // loser starts next
          room.broadcast({ type: 'move_made', row, col, symbol, nextTurn: null });
          room.broadcast({ type: 'game_over', winner: symbol, reason: 'line' });
        } else if (isFull(room.board)) {
          room.status = 'finished';
          room.nextStarter = room.nextStarter === PLAYER_X ? PLAYER_O : PLAYER_X; // alternate on draw
          room.broadcast({ type: 'move_made', row, col, symbol, nextTurn: null });
          room.broadcast({ type: 'game_over', winner: null, reason: 'draw' });
        } else {
          room.turn = player.symbol === PLAYER_X ? PLAYER_O : PLAYER_X;
          room.broadcast({
            type: 'move_made',
            row,
            col,
            symbol,
            nextTurn: SYMBOL[room.turn],
          });
        }
        break;
      }

      case 'rematch_request': {
        const room = currentRoom;
        if (!room) return;
        room.board = createBoard(room.boardSize);
        room.turn = room.nextStarter;
        room.status = 'playing';
        room.broadcast({ type: 'rematch_start', nextTurn: SYMBOL[room.turn] });
        break;
      }

      case 'leave_room': {
        cleanupPlayer();
        break;
      }

      default:
        send(ws, { type: 'error', message: 'unknown_message_type' });
    }
  });

  function cleanupPlayer() {
    if (!currentRoom) return;
    currentRoom.players = currentRoom.players.filter((p) => p.id !== playerId);
    if (currentRoom.players.length === 0) {
      rooms.delete(currentRoom.code);
    } else {
      currentRoom.status = 'waiting';
      currentRoom.broadcast({ type: 'opponent_left' });
    }
    currentRoom = null;
  }

  ws.on('close', cleanupPlayer);
  ws.on('error', cleanupPlayer);
}

module.exports = { handleGameConnection };
