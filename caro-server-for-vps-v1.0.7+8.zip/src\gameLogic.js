'use strict';

// Server-side authoritative board rules, mirroring app/lib/game/board_logic.dart.
// The server never trusts the client's idea of "I won" — it recomputes it.
//
// The board is a sparse map (not a fixed-size 2D array) plus a growing
// bounding box: playing on the current outer edge of any side extends that
// side by EXPAND_EDGE_BY more rows/cols, so nobody ever gets boxed in by a
// hard wall. Both server and client apply the exact same rule to the exact
// same ordered move sequence, so their bounds stay in sync without the
// server needing to broadcast them explicitly.

const EMPTY = 0;
const EXPAND_EDGE_BY = 5;
// Each side may only expand this many times (+10 rows/cols beyond the
// initial size by default) — otherwise a client could keep replaying edge
// moves to force the board arbitrarily large, and every later move then
// costs O(rows*cols) here (candidate scans, isFull). Capping growth caps
// that cost regardless of what any client sends.
const MAX_EXPANSIONS_PER_SIDE = 2;

function createBoard(size) {
  return {
    cells: new Map(),
    minRow: 0,
    maxRow: size - 1,
    minCol: 0,
    maxCol: size - 1,
    topExpansions: 0,
    bottomExpansions: 0,
    leftExpansions: 0,
    rightExpansions: 0,
  };
}

function key(r, c) {
  return `${r},${c}`;
}

function at(board, r, c) {
  return board.cells.get(key(r, c)) ?? EMPTY;
}

function isInside(board, r, c) {
  return r >= board.minRow && r <= board.maxRow && c >= board.minCol && c <= board.maxCol;
}

function place(board, r, c, player) {
  board.cells.set(key(r, c), player);
  if (r === board.minRow && board.topExpansions < MAX_EXPANSIONS_PER_SIDE) {
    board.minRow -= EXPAND_EDGE_BY;
    board.topExpansions++;
  }
  if (r === board.maxRow && board.bottomExpansions < MAX_EXPANSIONS_PER_SIDE) {
    board.maxRow += EXPAND_EDGE_BY;
    board.bottomExpansions++;
  }
  if (c === board.minCol && board.leftExpansions < MAX_EXPANSIONS_PER_SIDE) {
    board.minCol -= EXPAND_EDGE_BY;
    board.leftExpansions++;
  }
  if (c === board.maxCol && board.rightExpansions < MAX_EXPANSIONS_PER_SIDE) {
    board.maxCol += EXPAND_EDGE_BY;
    board.rightExpansions++;
  }
}

function checkWinAt(board, winLength, row, col) {
  const player = at(board, row, col);
  if (player === EMPTY) return { won: false };

  const directions = [
    [0, 1],
    [1, 0],
    [1, 1],
    [1, -1],
  ];

  for (const [dr, dc] of directions) {
    let count = 1;
    let r = row + dr;
    let c = col + dc;
    while (at(board, r, c) === player) {
      count++;
      r += dr;
      c += dc;
    }
    r = row - dr;
    c = col - dc;
    while (at(board, r, c) === player) {
      count++;
      r -= dr;
      c -= dc;
    }
    if (count >= winLength) return { won: true, player };
  }
  return { won: false };
}

function isFull(board) {
  for (let r = board.minRow; r <= board.maxRow; r++) {
    for (let c = board.minCol; c <= board.maxCol; c++) {
      if (at(board, r, c) === EMPTY) return false;
    }
  }
  return true;
}

module.exports = { EMPTY, createBoard, at, isInside, place, checkWinAt, isFull };
