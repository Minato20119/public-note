'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// The private chat's access code is now a fixed formula, not something the
// app can set/rotate: today's valid code is always PRIVATE_KEY + the last
// digit of today's day-of-month (e.g. private key "88888888" on the 22nd ->
// "888888882"). PRIVATE_KEY lives in a plain-text file that only whoever has
// VPS access can edit — the app itself never sees or stores it, only the
// resulting daily code the user types in.
const DATA_DIR = path.join(__dirname, '..', 'data');
const PRIVATE_KEY_FILE = path.join(DATA_DIR, 'private_key.txt');
const DEFAULT_PRIVATE_KEY = '88888888';

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(PRIVATE_KEY_FILE)) {
  fs.writeFileSync(PRIVATE_KEY_FILE, DEFAULT_PRIVATE_KEY);
}

// Re-read from disk on every check (cheap, and this file changes rarely) so
// an admin editing it directly on the VPS takes effect immediately, with no
// need to restart the Node process.
function readPrivateKey() {
  try {
    const value = fs.readFileSync(PRIVATE_KEY_FILE, 'utf8').trim();
    return value || DEFAULT_PRIVATE_KEY;
  } catch {
    return DEFAULT_PRIVATE_KEY;
  }
}

function lastDigitOfToday() {
  return String(new Date().getDate() % 10);
}

function currentValidCode() {
  return readPrivateKey() + lastDigitOfToday();
}

function sha256(text) {
  return crypto.createHash('sha256').update(text, 'utf8').digest('hex');
}

function timingSafeHexEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const bufA = Buffer.from(a, 'hex');
  const bufB = Buffer.from(b, 'hex');
  if (bufA.length === 0 || bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

function checkAccessHash(candidateHash) {
  return timingSafeHexEqual(candidateHash, sha256(currentValidCode()));
}

module.exports = { checkAccessHash };
