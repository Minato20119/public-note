'use strict';

const fs = require('fs');
const path = require('path');
const http = require('http');
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const { WebSocketServer } = require('ws');

const { handleGameConnection } = require('./gameHub');
const { handleChatConnection } = require('./chatHub');
const { handlePresenceConnection } = require('./presenceHub');
const { checkAccessHash } = require('./chatAuth');

const PORT = process.env.PORT || 8080;
const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
const WEB_APP_DIR = path.join(__dirname, '..', '..', 'app', 'build', 'web');

const app = express();
app.use(cors());

// Same shared-secret check as the chat WebSocket (see chatAuth.js) — without
// this, anyone who finds the server could upload arbitrary files here even
// without ever knowing the app's private-chat passphrase.
//
// Accepts the hash from either the `x-access-hash` header (used by the
// Dart `http` package for uploads, and by images on web/mobile) or a `h`
// query param — HTML5 <video> (and plain <img>) elements have no way to
// attach a custom header to the request the browser makes for their `src`,
// so video playback needs the hash embedded in the URL itself instead.
function requireChatAuth(req, res, next) {
  const hash = req.get('x-access-hash') || req.query.h;
  if (!checkAccessHash(hash)) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  next();
}

// Uploaded media (chat attachments) is only ever meant to be reachable by
// someone who has already authenticated into the hidden chat — gate the GET
// route the same way the POST /upload route already is, otherwise anyone who
// guesses/enumerates a filename can view private media with no auth at all.
app.use(
  '/uploads',
  requireChatAuth,
  (req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    next();
  },
  express.static(UPLOAD_DIR),
);
// Serves the compiled Flutter web build (production mode — no dwds debug
// channel, so it doesn't drop the page out from under an in-progress game
// the way `flutter run` dev mode occasionally does).
app.use(express.static(WEB_APP_DIR));

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`);
  },
});

const ALLOWED_EXT = new Set(['.jpg', '.jpeg', '.png', '.gif', '.webp', '.mp4', '.mov', '.webm']);
const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, ALLOWED_EXT.has(ext));
  },
});

app.post('/upload', requireChatAuth, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'no_file_or_unsupported_type' });
  const ext = path.extname(req.file.originalname).toLowerCase();
  const type = ['.mp4', '.mov', '.webm'].includes(ext) ? 'video' : 'image';
  res.json({ url: `/uploads/${req.file.filename}`, type });
});

// Uploaded media isn't tied to how long its chat message is kept (a message
// can be set to never auto-delete, or the file could outlive a deleted
// message entirely) — without this, disk usage on the /uploads/ dir only
// ever grows. Deleting the file after 7 days is independent of message
// retention; the chat UI already shows a broken-image/broken-video state
// gracefully when an attachment's file is gone.
const UPLOAD_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;

function sweepOldUploads() {
  fs.readdir(UPLOAD_DIR, (err, files) => {
    if (err) return;
    const cutoff = Date.now() - UPLOAD_MAX_AGE_MS;
    for (const file of files) {
      const filePath = path.join(UPLOAD_DIR, file);
      fs.stat(filePath, (statErr, stats) => {
        if (statErr || !stats.isFile()) return;
        if (stats.mtimeMs < cutoff) fs.unlink(filePath, () => {});
      });
    }
  });
}

sweepOldUploads();
setInterval(sweepOldUploads, 60 * 60 * 1000); // hourly is plenty for a 7-day window

app.get('/health', (_req, res) => res.json({ ok: true }));

const server = http.createServer(app);

const gameWss = new WebSocketServer({ noServer: true });
gameWss.on('connection', handleGameConnection);

const chatWss = new WebSocketServer({ noServer: true });
chatWss.on('connection', handleChatConnection);

const presenceWss = new WebSocketServer({ noServer: true });
presenceWss.on('connection', handlePresenceConnection);

server.on('upgrade', (req, socket, head) => {
  const { pathname } = new URL(req.url, `http://${req.headers.host}`);
  if (pathname === '/ws/game') {
    gameWss.handleUpgrade(req, socket, head, (ws) => gameWss.emit('connection', ws, req));
  } else if (pathname === '/ws/chat') {
    chatWss.handleUpgrade(req, socket, head, (ws) => chatWss.emit('connection', ws, req));
  } else if (pathname === '/ws/presence') {
    presenceWss.handleUpgrade(req, socket, head, (ws) => presenceWss.emit('connection', ws, req));
  } else {
    socket.destroy();
  }
});

server.listen(PORT, () => {
  console.log(`Caro Master server listening on :${PORT}`);
  console.log(`  game ws: ws://<host>:${PORT}/ws/game`);
  console.log(`  chat ws: ws://<host>:${PORT}/ws/chat`);
  console.log(`  uploads: http://<host>:${PORT}/upload (POST, field "file")`);
});
