'use strict';

const fs = require('fs');
const path = require('path');
const { v4: uuid } = require('uuid');
const chatAuth = require('./chatAuth');
const { isConfigured, checkAccessHash } = chatAuth;

const DATA_DIR = path.join(__dirname, '..', 'data');
const HISTORY_FILE = path.join(DATA_DIR, 'chat_history.json');
const IDENTITY_FILE = path.join(DATA_DIR, 'chat_identities.json');
const RETENTION_FILE = path.join(DATA_DIR, 'chat_retention.json');
const MAX_HISTORY = 500;

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

/** @type {any[]} */
let history = [];
try {
  history = JSON.parse(fs.readFileSync(HISTORY_FILE, 'utf8'));
} catch {
  history = [];
}

function persist() {
  const trimmed = history.slice(-MAX_HISTORY);
  fs.writeFile(HISTORY_FILE, JSON.stringify(trimmed), () => {});
}

// Maps a chosen clientId to the bearer token its device proved ownership of
// on first use (trust-on-first-use, same model as the access-code bootstrap
// in chatAuth.js) — without this, any authenticated participant could send
// `clientId: <someone else's id>` and impersonate them, including deleting
// their messages (delete_message only checks senderId === client.id).
/** @type {Record<string, string>} clientId -> owner token */
let identities = {};
try {
  identities = JSON.parse(fs.readFileSync(IDENTITY_FILE, 'utf8'));
} catch {
  identities = {};
}

function persistIdentities() {
  fs.writeFile(IDENTITY_FILE, JSON.stringify(identities), () => {});
}

// "Disappearing messages" retention window shared by the whole conversation
// (there's only ever one chat "room" here) — null means off. Only 6h/24h are
// offered, matching what the app's UI exposes.
const AUTO_DELETE_WINDOWS = new Set([6 * 60 * 60 * 1000, 24 * 60 * 60 * 1000]);
/** @type {number | null} */
let autoDeleteWindowMs = null;
try {
  const saved = JSON.parse(fs.readFileSync(RETENTION_FILE, 'utf8'));
  autoDeleteWindowMs = AUTO_DELETE_WINDOWS.has(saved.windowMs) ? saved.windowMs : null;
} catch {
  autoDeleteWindowMs = null;
}

function persistRetention() {
  fs.writeFile(RETENTION_FILE, JSON.stringify({ windowMs: autoDeleteWindowMs }), () => {});
}

function broadcastHistory() {
  broadcast({ type: 'history', messages: history, autoDeleteWindowMs });
}

// Sweeps messages older than the current retention window and tombstones
// them the same way a manual delete does (keeps a "message deleted"
// placeholder rather than silently shrinking the list). Runs on a timer and
// also right after the window changes, so shortening it takes effect
// immediately instead of waiting for the next tick.
function sweepExpiredMessages() {
  if (!autoDeleteWindowMs) return;
  const cutoff = Date.now() - autoDeleteWindowMs;
  let changed = false;
  for (const m of history) {
    if (!m.deleted && m.timestamp < cutoff) {
      m.deleted = true;
      m.text = '';
      m.attachments = [];
      m.reactions = {};
      changed = true;
    }
  }
  if (changed) {
    persist();
    broadcastHistory();
  }
}

setInterval(sweepExpiredMessages, 60 * 1000);

// Only a relative path under this server's own /uploads/ dir is accepted as
// an attachment — otherwise a message could point at an arbitrary external
// URL, which every recipient's client would then fetch directly (leaking
// their IP to whoever controls that URL, or serving unexpected content).
const ATTACHMENT_URL_RE = /^\/uploads\/[A-Za-z0-9._-]+$/;

// Throttles repeated failed 'hello' attempts per IP — the access code hash
// itself is checked in constant time, but nothing stopped unlimited guesses
// over the WS otherwise.
const AUTH_WINDOW_MS = 5 * 60 * 1000;
const AUTH_MAX_FAILURES = 10;
/** @type {Map<string, {count: number, windowStart: number}>} */
const authFailures = new Map();

function isAuthRateLimited(ip) {
  const entry = authFailures.get(ip);
  if (!entry) return false;
  if (Date.now() - entry.windowStart > AUTH_WINDOW_MS) {
    authFailures.delete(ip);
    return false;
  }
  return entry.count >= AUTH_MAX_FAILURES;
}

function recordAuthFailure(ip) {
  const entry = authFailures.get(ip);
  if (!entry || Date.now() - entry.windowStart > AUTH_WINDOW_MS) {
    authFailures.set(ip, { count: 1, windowStart: Date.now() });
  } else {
    entry.count += 1;
  }
}

// Per-connection message/reaction rate limit — a spam flood is cheap to
// send and would otherwise get persisted and broadcast to everyone at full
// speed.
const ACTION_WINDOW_MS = 10 * 1000;
const ACTION_MAX = 20;

/** @type {Set<{ws: any, id: string, name: string}>} */
const clients = new Set();

function send(ws, payload) {
  if (ws.readyState === ws.OPEN) ws.send(JSON.stringify(payload));
}

function broadcast(payload, exceptWs) {
  for (const c of clients) {
    if (c.ws !== exceptWs) send(c.ws, payload);
  }
}

function broadcastPresence() {
  const names = [...clients].map((c) => ({ id: c.id, name: c.name }));
  broadcast({ type: 'presence', users: names });
}

function handleChatConnection(ws, req) {
  const ip = req?.socket?.remoteAddress || 'unknown';
  const client = { ws, id: uuid(), name: 'Ẩn danh' };
  let authenticated = false;
  /** @type {number[]} */
  let actionTimestamps = [];

  function tooManyActions() {
    const now = Date.now();
    actionTimestamps = actionTimestamps.filter((t) => now - t < ACTION_WINDOW_MS);
    actionTimestamps.push(now);
    return actionTimestamps.length > ACTION_MAX;
  }

  ws.on('message', (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch {
      return send(ws, { type: 'error', message: 'invalid_json' });
    }

    if (!authenticated && msg.type !== 'hello') {
      return send(ws, { type: 'error', message: 'unauthorized' });
    }

    switch (msg.type) {
      case 'hello': {
        if (isAuthRateLimited(ip)) {
          send(ws, { type: 'error', message: 'rate_limited' });
          return ws.close(4429, 'rate_limited');
        }

        const validHash = typeof msg.accessHash === 'string' && msg.accessHash.length === 64;
        const bootstrapping = !isConfigured();

        if (bootstrapping) {
          // Nothing configured yet anywhere (no env var, no persisted file)
          // — the first code anyone connects with becomes the secret, so a
          // fresh server works the moment the app sets a code, no separate
          // server-side setup step required.
          if (!validHash || !chatAuth.bootstrap(msg.accessHash)) {
            recordAuthFailure(ip);
            send(ws, { type: 'error', message: 'unauthorized' });
            return ws.close(4401, 'unauthorized');
          }
        } else if (!validHash || !checkAccessHash(msg.accessHash)) {
          recordAuthFailure(ip);
          send(ws, { type: 'error', message: 'unauthorized' });
          return ws.close(4401, 'unauthorized');
        }

        // Already proved knowledge of the current code above — optionally
        // rotate to a new one in the same round trip (e.g. the user changed
        // their passphrase in Settings).
        if (!bootstrapping && typeof msg.rotateToHash === 'string' && msg.rotateToHash.length === 64) {
          const rotated = chatAuth.rotate(msg.rotateToHash);
          send(ws, {
            type: rotated ? 'access_code_changed' : 'error',
            message: rotated ? undefined : 'rotate_not_allowed',
          });
        }

        authenticated = true;
        clients.add(client);
        if (typeof msg.name === 'string' && msg.name.trim()) {
          client.name = msg.name.trim().slice(0, 40);
        }

        // Only take over the requested clientId if either (a) nobody has
        // claimed it yet — first use registers this token as its owner —
        // or (b) this connection presents the same token that claimed it
        // before. Otherwise silently keep the fresh uuid generated above,
        // so a connection that doesn't know the real owner's token can't
        // pose as them (see the identities map comment above).
        const requestedId = typeof msg.clientId === 'string' && msg.clientId ? msg.clientId : null;
        const token =
          typeof msg.identityToken === 'string' && msg.identityToken.length >= 16
            ? msg.identityToken
            : null;
        if (requestedId) {
          const owner = identities[requestedId];
          if (owner) {
            if (token && owner === token) client.id = requestedId;
          } else if (token) {
            identities[requestedId] = token;
            persistIdentities();
            client.id = requestedId;
          }
        }

        send(ws, { type: 'history', messages: history, autoDeleteWindowMs });
        broadcastPresence();
        break;
      }

      case 'message': {
        if (tooManyActions()) return send(ws, { type: 'error', message: 'rate_limited' });
        const text = typeof msg.text === 'string' ? msg.text.slice(0, 4000) : '';
        const attachments = Array.isArray(msg.attachments)
          ? msg.attachments
              .filter(
                (a) =>
                  a &&
                  (a.type === 'image' || a.type === 'video') &&
                  typeof a.url === 'string' &&
                  ATTACHMENT_URL_RE.test(a.url),
              )
              .map((a) => ({ type: a.type, url: a.url }))
              .slice(0, 10)
          : [];
        if (!text && attachments.length === 0) return;

        const message = {
          id: uuid(),
          tempId: msg.tempId || null,
          senderId: client.id,
          senderName: client.name,
          text,
          attachments,
          replyTo: msg.replyTo || null,
          timestamp: Date.now(),
          reactions: {},
        };
        history.push(message);
        // Keep the in-memory copy capped too — persist() only trimmed the
        // on-disk copy, so without this the array (and every 'history'
        // payload sent to new connections) grew without bound.
        if (history.length > MAX_HISTORY) history = history.slice(-MAX_HISTORY);
        persist();
        broadcast({ type: 'message', message });
        send(ws, { type: 'message', message }); // ack to sender too (resolves tempId)
        break;
      }

      case 'reaction': {
        if (tooManyActions()) return send(ws, { type: 'error', message: 'rate_limited' });
        const target = history.find((m) => m.id === msg.messageId);
        if (!target || typeof msg.emoji !== 'string') return;
        target.reactions ??= {};
        const users = (target.reactions[msg.emoji] ??= []);
        const idx = users.indexOf(client.id);
        if (idx >= 0) {
          users.splice(idx, 1); // toggle off
        } else {
          users.push(client.id);
        }
        if (users.length === 0) delete target.reactions[msg.emoji];
        persist();
        broadcast({
          type: 'reaction_update',
          messageId: target.id,
          reactions: target.reactions,
        });
        break;
      }

      case 'typing': {
        broadcast({ type: 'typing', from: client.name }, ws);
        break;
      }

      case 'delete_message': {
        const target = history.find((m) => m.id === msg.messageId);
        if (!target) return;
        if (target.senderId !== client.id) {
          return send(ws, { type: 'error', message: 'not_your_message' });
        }
        target.deleted = true;
        target.text = '';
        target.attachments = [];
        target.reactions = {};
        persist();
        broadcast({ type: 'message_deleted', messageId: target.id });
        send(ws, { type: 'message_deleted', messageId: target.id });
        break;
      }

      // Bulk-tombstones every message this connection's identity has sent,
      // anywhere in the conversation — leaves the other participant's
      // messages untouched.
      case 'clear_own_messages': {
        if (tooManyActions()) return send(ws, { type: 'error', message: 'rate_limited' });
        let changed = false;
        for (const m of history) {
          if (m.senderId === client.id && !m.deleted) {
            m.deleted = true;
            m.text = '';
            m.attachments = [];
            m.reactions = {};
            changed = true;
          }
        }
        if (changed) {
          persist();
          broadcastHistory();
        }
        break;
      }

      // Wipes the entire shared conversation for both participants — unlike
      // the tombstoning above, this is a full reset (empties history rather
      // than leaving 500 "deleted" placeholders behind).
      case 'clear_all_messages': {
        if (tooManyActions()) return send(ws, { type: 'error', message: 'rate_limited' });
        history = [];
        persist();
        broadcastHistory();
        break;
      }

      // Turns "disappearing messages" on/off for the whole conversation —
      // either participant can change it, same trust model as the shared
      // access code itself.
      case 'set_auto_delete': {
        if (tooManyActions()) return send(ws, { type: 'error', message: 'rate_limited' });
        const win = msg.windowMs;
        if (win === null) {
          autoDeleteWindowMs = null;
        } else if (typeof win === 'number' && AUTO_DELETE_WINDOWS.has(win)) {
          autoDeleteWindowMs = win;
        } else {
          return send(ws, { type: 'error', message: 'invalid_window' });
        }
        persistRetention();
        broadcast({ type: 'auto_delete_changed', windowMs: autoDeleteWindowMs });
        sweepExpiredMessages(); // apply immediately if shortening the window already expires older messages
        break;
      }

      default:
        send(ws, { type: 'error', message: 'unknown_message_type' });
    }
  });

  function cleanup() {
    if (!authenticated) return;
    clients.delete(client);
    broadcastPresence();
  }

  ws.on('close', cleanup);
  ws.on('error', cleanup);
}

module.exports = { handleChatConnection };
