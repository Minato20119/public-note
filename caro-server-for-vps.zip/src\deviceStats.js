'use strict';

const fs = require('fs');
const path = require('path');
const { EventEmitter } = require('events');

// Aggregate, anonymous install/usage counters only — no message content, no
// per-device detail is ever exposed past a count. Kept as its own module
// (rather than folded into chatHub) because it's driven by a separate
// /ws/presence connection that every install opens on app start, regardless
// of whether that install ever unlocks the private chat.
const DATA_DIR = path.join(__dirname, '..', 'data');
const REGISTRY_FILE = path.join(DATA_DIR, 'device_registry.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

/** @type {Record<string, {firstSeen: number, lastSeen: number}>} */
let registry = {};
try {
  registry = JSON.parse(fs.readFileSync(REGISTRY_FILE, 'utf8'));
} catch {
  registry = {};
}

function persistRegistry() {
  fs.writeFile(REGISTRY_FILE, JSON.stringify(registry), () => {});
}

// clientId -> set of currently-open presence sockets. A Set (not just a
// counter) so the same device reconnecting (or opening two tabs on web)
// still only ever counts as one online device.
/** @type {Map<string, Set<any>>} */
const onlineByClient = new Map();

const emitter = new EventEmitter();

function recordDevice(clientId) {
  const now = Date.now();
  if (!registry[clientId]) {
    registry[clientId] = { firstSeen: now, lastSeen: now };
  } else {
    registry[clientId].lastSeen = now;
  }
  persistRegistry();
}

function markOnline(clientId, socket) {
  recordDevice(clientId);
  let sockets = onlineByClient.get(clientId);
  if (!sockets) {
    sockets = new Set();
    onlineByClient.set(clientId, sockets);
  }
  sockets.add(socket);
  emitter.emit('change');
}

function markOffline(clientId, socket) {
  const sockets = onlineByClient.get(clientId);
  if (!sockets) return;
  sockets.delete(socket);
  if (sockets.size === 0) onlineByClient.delete(clientId);
  emitter.emit('change');
}

function getStats() {
  return {
    totalDevices: Object.keys(registry).length,
    onlineDevices: onlineByClient.size,
  };
}

function onChange(listener) {
  emitter.on('change', listener);
}

module.exports = { markOnline, markOffline, getStats, onChange };
