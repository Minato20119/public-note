'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// The private chat is only as secret as whoever can reach this WebSocket —
// the app's on-device passphrase gate is a UI nicety, not real access
// control, unless the server itself also checks a shared secret too.
// Clients never send the phrase itself, only its SHA-256 hex digest, and
// comparisons below are constant-time so a timing side-channel can't leak
// how much of the hash matched.
//
// Where that shared secret comes from, in priority order:
//  1. CHAT_ACCESS_CODE env var, if set — fixed for the life of the process,
//     for anyone who wants the server to be the sole authority (can't be
//     changed from the app).
//  2. A secret persisted in data/chat_secret.json, set by whichever device
//     rotates it from the app's Settings screen (see 'rotate' below).
//  3. Neither configured yet: "bootstrap" mode — the very first successful
//     connection's access code is adopted as the secret and persisted, so a
//     fresh install works the moment you pick a code in the app, with no
//     separate server-side setup step.
const DATA_DIR = path.join(__dirname, '..', 'data');
const SECRET_FILE = path.join(DATA_DIR, 'chat_secret.json');

const envCode = process.env.CHAT_ACCESS_CODE || '';
const fixedHash = envCode ? sha256(envCode) : null;

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

let persistedHash = null;
if (!fixedHash) {
  try {
    persistedHash = JSON.parse(fs.readFileSync(SECRET_FILE, 'utf8')).hash || null;
  } catch {
    persistedHash = null;
  }
}

function sha256(text) {
  return crypto.createHash('sha256').update(text, 'utf8').digest('hex');
}

function isFixedByEnv() {
  return fixedHash !== null;
}

function currentHash() {
  return fixedHash ?? persistedHash;
}

function isConfigured() {
  return currentHash() !== null;
}

function timingSafeHexEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const bufA = Buffer.from(a, 'hex');
  const bufB = Buffer.from(b, 'hex');
  if (bufA.length === 0 || bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

function checkAccessHash(candidateHash) {
  const expected = currentHash();
  if (!expected) return false;
  return timingSafeHexEqual(candidateHash, expected);
}

/// Called when nothing is configured yet: adopts whatever hash the first
/// connecting client presents as the permanent secret from now on.
function bootstrap(hash) {
  if (typeof hash !== 'string' || hash.length !== 64) return false;
  persistedHash = hash;
  fs.writeFile(SECRET_FILE, JSON.stringify({ hash }), () => {});
  return true;
}

/// Rotates the secret — only allowed if the caller already proved they know
/// the *current* one (checked by the caller before calling this), and only
/// when the secret isn't pinned by CHAT_ACCESS_CODE.
function rotate(newHash) {
  if (isFixedByEnv()) return false;
  if (typeof newHash !== 'string' || newHash.length !== 64) return false;
  persistedHash = newHash;
  fs.writeFile(SECRET_FILE, JSON.stringify({ hash: newHash }), () => {});
  return true;
}

if (!isConfigured()) {
  console.warn(
    '[chatAuth] No chat access code configured yet — the first client to ' +
      'connect with a code will set it (see server/data/chat_secret.json).',
  );
} else if (isFixedByEnv()) {
  console.log('[chatAuth] Chat access code fixed by CHAT_ACCESS_CODE env var.');
} else {
  console.log('[chatAuth] Chat access code loaded from server/data/chat_secret.json.');
}

module.exports = { isConfigured, isFixedByEnv, checkAccessHash, bootstrap, rotate };
